import 'cypress-fill-command'
describe('Send DSR', () => {
it('Send DSR for Today', () => {
 
const DSR =['Working on Rest Assured Framework Explore GIT and GIT Hub  Working on Recrutex application  attende meeting for Task management application ']

const randomIndex = Math.floor(Math.random() * DSR.length)
const randomDSR = DSR[randomIndex]
 
cy.visit('http://14.99.138.131:8890/login')
cy.get('#username').fill('graceepsiba.sunkara@ojas-it.com')
cy.get('#password').fill('Test@123')
cy.get('.btn').click()
cy.get('.bi-list').click()
cy.get('#sidebar > :nth-child(2) > :nth-child(3) > .nav-link').click()
 
// Date
const currentDate = new Date();
const formattedDate = `${currentDate.getFullYear()}-${(currentDate.getMonth() + 1)
.toString()
.padStart(2, '0')}-${currentDate.getDate().toString().padStart(2, '0')}`;
cy.get('#dsrDate').fill(formattedDate)
cy.get('#hrs').fill('8')
cy.get('#taskDescription').fill(randomDSR)
cy.get('#submitdate').click()
 
})
})