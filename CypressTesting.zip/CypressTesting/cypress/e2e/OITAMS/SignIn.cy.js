describe('Visit OITAMS',()=>
{
    it('visit OITAMS',()=>
    {
        cy.visit('https://adactinhotelapp.com/');
        cy.wait(3000);
        cy.xpath('//input[@name="username"]').type('veerasubbu');
        cy.xpath('//input[@name="password"]').type('veerasubbu');
        cy.xpath('//input[@name="login"]').click();
        //cy.get('.btn').click();
       
    })
})