import AdminTest from "../../POMObjects/Admin/AdminModuleTest"
describe('Admin Modules Test', () => {
    it('Checking the functionality of Admin Modules', () => {

        // Login to Admin
        const at = new AdminTest()
        at.visitAdminPage()

        // Approval Status
        at.approvalStatus()

        // check All
        at.checkAll()

        // Add Client
        at.addClient()

        // Add Tech
        at.addTech()
    })
})