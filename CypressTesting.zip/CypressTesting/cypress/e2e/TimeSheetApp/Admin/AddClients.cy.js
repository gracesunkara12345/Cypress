import NewClient from '../../POMObjects/Admin/NewClientOb'
describe('Add New Role', () => {
    beforeEach(() => {
        const cn = new NewClient()
        cn.visitNewClient()
      });
    it('Adding a new Role with Admin Credentials', () => {

        cy.fixture('clients').then((data) => {
            const clientsNames = data.clientsNames;
            clientsNames.forEach((clientName) => {
                cy.get('label > input').type(clientName)
                cy.get('#clientName').type(clientName)
                cy.wait(2000)
                cy.get('#submitbtnRegion').click()
                cy.wait(3000)
            })
        })


    })
})