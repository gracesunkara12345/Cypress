import faker from 'faker';
import PendingStatus from "../../POMObjects/Admin/PendingStatus"
describe('Admin Modules Test', () => {
    it('Checking the functionality of Admin Modules', () => {

        const ps = new PendingStatus()
        ps.visitPendingStatus()
        cy.get('#startdate').type('2023-08-01')
        cy.wait(2000)
        cy.get('#submitdate').click()
        cy.wait(3000)

        // Approved Status
        cy.get('.bi-list').click()
        cy.get(':nth-child(3) > .nav-link').click()
        cy.get('#startdate').type('2023-08-01')
        cy.wait(2000)
        cy.get('#submitdate').click()
        cy.wait(3000)

        // Check All
        cy.get('.bi-list').click()
        cy.get(':nth-child(4) > .nav-link').click()
        cy.get('#startdate').type('2023-08-01')
        cy.wait(2000)
        cy.get('#submitdate').click()
        cy.wait(3000)

        // Resource Status
        cy.get('.bi-list').click()
        cy.get(':nth-child(5) > .nav-link').click()

        // Add New Client
        cy.get('.bi-list').click()
        cy.get(':nth-child(6) > .nav-link').click()
        const clientName = faker.company.companyName()
        cy.get('label > input').type(clientName)
        cy.wait(3000)
        cy.get('#clientName').type(clientName)
        cy.get('#submitbtnRegion').click()
        cy.wait(2000)
        cy.get('label > input').type(clientName)
        cy.wait(3000)

        // Add New Techology
        cy.get('.bi-list').click()
        cy.get(':nth-child(7) > .nav-link').click()
        const techName = faker.hacker.noun();
        cy.get('label > input').type(techName)
        cy.wait(3000)
        cy.get('#techName').type(techName)
        cy.get('#submitbtnRegion').click()
        cy.wait(2000)
        cy.get('label > input').type(techName)
        cy.wait(2000)

        // Add New Role
        cy.get('.bi-list').click()
        cy.get(':nth-child(8) > .nav-link').click()
        const empId  = faker.random.number({ min: 21000, max: 21999 });
        const firstName = faker.name.firstName();
        const lastName = faker.name.lastName();
        const empName = `${firstName} ${lastName}`;
        const email = `${lastName}.${firstName}@ojas-it.com`
        const phNo = faker.random.number({ min: 900000000, max: 9999999999 });
        const gender = faker.random.number({ min: 1, max: 2 });
        
        // Add New Client
        cy.get('#empId').type(empId)
        cy.get('#empName').type(empName)
        cy.get('#emailId').type(email)
        cy.get('#password').type('Ojas@15251525')
        cy.get('#domain').find('option').then(options => {
        const numberOfOptions = options.length;
        const designation = faker.random.number({ min: 1, max: numberOfOptions - 1 });
        cy.get('#domain').select(designation);
        });

        cy.get('#phoneNumber').type(phNo)
        cy.get('#role').find('option').then(options => {
        const numb = options.length;
        const roles = faker.random.number({ min: 1, max: numb - 1 });
        cy.get('#role').select(roles)
        })
        cy.wait(2000)
        cy.fixture('car.jpg').then((fileContent) => {
          cy.get('#userpic').attachFile({
            fileContent,
            fileName: 'car.jpg',
            mimeType: 'image/jpg',
          });
        });
       
        cy.get(`#option${gender}`).click()
        cy.get('.col-12 > .btn').click()
        cy.wait(3000)

        // Pending TimeSheets
        cy.get('.bi-list').click()
        cy.get(':nth-child(9) > .nav-link').click()
        cy.get('#startdate').type('2023-08-01')
        cy.get('#submitdate').click()
        cy.wait(2000)
    })
})