import faker from 'faker';
import ITSM from "../../POMObjects/User/ITSMOb"
describe('Visit ITSM', () => {
    it('Visit ITSM in User', () => {

    const io = new ITSM()
    io.visitITSMPage()
    cy.get('label > input').type('PMO')

    cy.get('#department').find('option').then(options => {
    const numb = options.length;
    const dept = faker.random.number({ min: 1, max: numb - 1 });
    cy.get('#department').select(dept)

    const desc = faker.commerce.productDescription()
    cy.get('#issueDesc').type(desc)

    //cy.get('#submitbtnRegion').click()
    cy.wait(3000)

    cy.get('label > input').clear().type(desc)
    cy.get('#submitbtnRegion').should('not.be.visible');
    })
    })
})