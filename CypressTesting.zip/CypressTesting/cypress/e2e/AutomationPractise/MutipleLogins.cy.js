describe('Login Test', () => {
    beforeEach(() => {
        cy.visit('https://adactinhotelapp.com/')
      });
    it('Login with mutiple data', () => {
        cy.fixture('users.json').then((data) => {
                data.forEach((user) => {
                cy.get('#username').type(user.username)
                cy.get('#password').type(user.password)
                cy.get('#login').click()
                cy.wait(2000)
                cy.get('[href="Logout.php"]').click()
                cy.get('.reg_success > a').click()
            })
            })
    })
})