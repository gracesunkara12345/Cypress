

describe('Visit Guru',()=>
{

it('Visit Guru.com',()=>
{
cy.visit('https://www.guru99.com/');
cy.xp//input[@name='search']
})
})
