describe('Login Test', () => {
    it('Login with mutiple data', () => {
        cy.visit('https://demo.guru99.com/test/delete_customer.php')
        cy.get('[type="submit"]').click()

        cy.on("window:alert", (message) => {
            expect(message).to.equal("Hello, Cypress!");
        });

    })
})