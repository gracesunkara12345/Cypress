describe('Visit ITSM', () => {
    it('Visit ITSM in User', () => {
        cy.visit('http://192.168.1.65:8080/Recruitex-App/')
        cy.get('#login').type('vijaya.kadamati@ojas-it.com')
        cy.get('#password').type('123456')
        cy.get('#domain').type('ojas-it')
        cy.wait(11000)
        cy.get('form.ng-dirty > .btn').click()
        

    })
})
