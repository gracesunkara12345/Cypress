import faker from 'faker';
describe('Random Name', () => {
    it('Random Name using Faker', () => {

        const faker = require('faker');

        // First Name
        const randomFirstName = faker.name.firstName();
        cy.log(randomFirstName)

        // Last Name
        const randomLastName = faker.name.lastName();
        cy.log(randomLastName)

        // Name
        const randomName = faker.name.findName();
        cy.log(randomName)

        // Description
        const des = faker.lorem.paragraph();
        cy.log(des)
        
        // Number
        const randomNumber = faker.random.number({ min: 40, max: 99 })
        cy.log(randomNumber)

        // Email
        const randomEmail = faker.internet.email();
        cy.log(randomEmail)

        // Password
        const randomPassword = faker.internet.password();
        cy.log(randomPassword)

        // Job
        const job = faker.name.jobArea()
        cy.log(job)

       const company = faker.company.companyName()
       cy.log(company)

       const jobTitle = faker.name.jobTitle()
       cy.log(jobTitle)

    })
})