describe("Post Request", () => {
    it("Post Request in API", () => {

        cy.request ({

            method : 'POST',
            url : 'https://reqres.in/api/users',
            body : {
                
                    name: "Vinay",
                    job: "Testing"
                
                   }
    })

    .its('status')
    .should('equal', 201)

    })
})