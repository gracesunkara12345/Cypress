describe("PUT Request", () => {
    it("PUT Request in API", () => {

        cy.request ({

            method : 'PUT',
            url : 'https://reqres.in/api/users/2',
            body : {
                
                    name: "Vinay",
                    job: "Testing",
                    Exp : 2
                
                   }
    })

    .its('status')
    .should('equal', 200)

    })
})