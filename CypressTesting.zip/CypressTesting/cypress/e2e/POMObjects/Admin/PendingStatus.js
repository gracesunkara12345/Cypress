class PendingStatus
{
    visitPendingStatus()
    {
        cy.visit('http://192.168.3.106:8890/login')
        cy.get('#username').type('pavithra.resoju@ojas-it.com')
        cy.get('#password').type('Ojas@1525')
        cy.get('.btn-primary').click()
        cy.wait(2000)
        cy.get('.bi-list').click()
        cy.get('.nav > :nth-child(2) > .nav-link').click()
    }

}

export default PendingStatus;