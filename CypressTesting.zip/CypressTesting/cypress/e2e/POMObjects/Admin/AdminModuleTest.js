import faker from 'faker';
class AdminTest
{
    visitAdminPage()
    {
        cy.visit('http://192.168.3.106:8890/login')
        cy.get('#username').type('pavithra.resoju@ojas-it.com')
        cy.get('#password').type('Ojas@1525')
        cy.get('.btn-primary').click()
        cy.wait(2000)
        cy.get('.bi-list').click()
        cy.get('.nav > :nth-child(2) > .nav-link').click()
    }

    approvalStatus()
    {
        cy.get('.bi-list').click()
        cy.get(':nth-child(3) > .nav-link').click()
        cy.get('#startdate').type('2023-08-01')
        cy.wait(2000)
        cy.get('#submitdate').click()
        cy.wait(3000)
    }

    checkAll()
    {
        cy.get('.bi-list').click()
        cy.get(':nth-child(4) > .nav-link').click()
        cy.get('#startdate').type('2023-08-01')
        cy.wait(2000)
        cy.get('#submitdate').click()
        cy.wait(3000)
    }

    addClient()
    {
        cy.get('.bi-list').click()
        cy.get(':nth-child(6) > .nav-link').click()
        const clientName = faker.company.companyName()
        cy.get('label > input').type(clientName)
        cy.wait(3000)
        cy.get('#clientName').type(clientName)
        cy.get('#submitbtnRegion').click()
        cy.wait(2000)
        cy.get('label > input').type(clientName)
        cy.wait(3000)
        //cy.get('.odd > :nth-child(2)').should('have.value', clientName)
    }

    addTech()
    {
        cy.get('.bi-list').click()
        cy.get(':nth-child(7) > .nav-link').click()
        const techName = faker.hacker.noun();
        cy.get('label > input').type(techName)
        cy.wait(3000)
        cy.get('#techName').type(techName)
        cy.get('#submitbtnRegion').click()
        cy.wait(2000)
        cy.get('label > input').type(techName)
        cy.wait(2000)
       // cy.get('.odd > :nth-child(2)').should('have.value',techName)
    }


}

export default AdminTest;