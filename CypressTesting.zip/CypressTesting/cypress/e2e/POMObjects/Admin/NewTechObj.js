class NewTechnology
{
    visitNewTech()
    {
        cy.visit('http://192.168.3.106:8890/login')
        cy.get('#username').type('pavithra.resoju@ojas-it.com')
        cy.get('#password').type('Ojas@1525')
        cy.get('.btn').click()
        cy.get('.bi-list').click()
        cy.get(':nth-child(7) > .nav-link').click()
        cy.wait(2000)
    }


}

export default NewTechnology;