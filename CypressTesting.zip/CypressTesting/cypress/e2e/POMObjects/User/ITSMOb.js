class ITSM
{
    visitITSMPage()
    {
        cy.visit('http://192.168.3.106:8890/login')
        cy.get('#username').type('divya.thandra@ojas-it.com')
        cy.get('#password').type('Divya@12345')
        cy.get('.btn').click()
        cy.wait(2000)
        cy.get('.bi-list').click()
        cy.get(':nth-child(4) > .nav-link').click()
        cy.wait(2000)
    }
}

export default ITSM;