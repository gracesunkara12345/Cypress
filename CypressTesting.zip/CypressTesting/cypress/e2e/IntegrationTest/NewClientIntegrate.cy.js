import faker from 'faker';
import NewClient from "../POMObjects/Admin/NewClientOb"
import FillTimeSheets from "../POMObjects/User/FillTimeSheetOb"
describe('Add New Client', () => {
   const clientName = faker.company.companyName()
it('Add New Client and Validate client is added Successfully', () => {

   const nc = new NewClient()
   nc.visitNewClient()
        cy.get('label > input').type(clientName)
        cy.wait(3000)
        cy.get('#clientName').type(clientName)
        cy.get('#submitbtnRegion').click()
        cy.wait(2000)
        cy.get('label > input').type(clientName)
        cy.wait(3000)

})

it('Validate New Client is displaying in User Role', () => {

      const ft = new FillTimeSheets()
      ft.visitTimeSheet()
      const lowercase = clientName.toLowerCase()
      cy.get('#clientName').select(lowercase)



})

})